#ifndef __LIB_TIME_H__
#define __LIB_TIME_H__

void print_time(const char * const head);

#endif
